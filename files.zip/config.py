"""
Routes for config.yaml generation, engine management, and survey proxy.

Config & Engine lifecycle:
  POST /api/v1/config/generate  — build config.yaml from DB state
  POST /api/v1/engine/start     — generate config + start engine (Docker or local)
  POST /api/v1/engine/stop      — stop the running engine
  GET  /api/v1/engine/status    — check if engine is running

Survey proxy (platform :8080 → engine :8000):
  POST /api/v1/survey/{room}/capture  — capture live RSSI as fingerprint
  POST /api/v1/survey/{room}          — submit manual RSSI vector
  GET  /api/v1/survey/status          — radiomap overview
  GET  /api/v1/survey/radiomap        — full radiomap JSON
  DELETE /api/v1/survey/{room}        — delete room fingerprints
"""

import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import httpx
import yaml

from models import get_db, EngineLog
from config_gen.generator import generate_config
from engine_mgr.docker_ctl import start_engine, stop_engine, engine_status

log = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1", tags=["config"])

# Engine connection — mirrors the resolved value in main.py
ENGINE_PORT    = int(os.environ.get("ENGINE_PORT", 8000))
ENGINE_API_URL = os.environ.get("ENGINE_API_URL", f"http://localhost:{ENGINE_PORT}")

# "docker" = production (docker run), "local" = desktop_app.py / dev terminal
ENGINE_MODE = os.environ.get("ENGINE_MODE", "local")


def _log_engine_event(db: Session, level: str, message: str, meta: dict | None = None) -> None:
    """Write an engine lifecycle event to the EngineLog table."""
    try:
        db.add(EngineLog(
            level=level,
            source="system",
            message=message,
            meta=meta or {},
            timestamp=datetime.now(timezone.utc),
        ))
        db.commit()
    except Exception as exc:
        log.warning("Failed to log engine event: %s", exc)


# ── Config generation ─────────────────────────────────────────────────────────

@router.post("/config/generate")
def generate(
    campus_id: int,
    building: Optional[str] = None,
    floor: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """
    Generate config.yaml from the current database state.
    Returns the YAML as JSON (for preview) and writes it to disk.
    """
    try:
        cfg = generate_config(db, campus_id, building, floor)
    except ValueError as e:
        raise HTTPException(404, str(e))

    hybrid_dir  = os.path.join(os.path.dirname(__file__), "..", "..", "..", "Hybrid")
    config_path = os.path.join(hybrid_dir, "config.yaml")
    try:
        with open(config_path, "w", encoding="utf-8") as f:
            yaml.dump(cfg, f, default_flow_style=False, sort_keys=False)
    except Exception as exc:
        raise HTTPException(500, f"Failed to write config.yaml: {exc}")

    return {"ok": True, "config": cfg, "path": config_path}


# ── Engine lifecycle ──────────────────────────────────────────────────────────

def _start_engine_local(cfg: dict) -> Dict[str, Any]:
    """
    Push config to a locally-running engine and start its poll loop.
    This is the non-Docker path used by desktop_app.py.
    """
    try:
        with httpx.Client(timeout=5.0) as client:
            resp = client.post(f"{ENGINE_API_URL}/config", json=cfg)
            if resp.status_code != 200:
                return {"ok": False, "error": f"Config push failed: {resp.status_code} {resp.text}"}
            resp = client.post(f"{ENGINE_API_URL}/poll/start")
            if resp.status_code != 200:
                return {"ok": False, "error": f"Poll start failed: {resp.status_code} {resp.text}"}
            return {"ok": True, "mode": "local", "message": f"Config pushed, poll started on {ENGINE_API_URL}"}
    except httpx.ConnectError:
        return {"ok": False, "error": f"Engine not reachable at {ENGINE_API_URL}. Is it running?"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def _stop_engine_local() -> Dict[str, Any]:
    """Stop the poll loop on a locally-running engine."""
    try:
        with httpx.Client(timeout=5.0) as client:
            resp = client.post(f"{ENGINE_API_URL}/poll/stop")
            if resp.status_code == 200:
                return {"ok": True, "mode": "local", "message": "Poll loop stopped"}
            return {"ok": False, "error": f"Stop failed: {resp.status_code} {resp.text}"}
    except httpx.ConnectError:
        return {"ok": False, "error": f"Engine not reachable at {ENGINE_API_URL}"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


@router.post("/engine/start")
def start(
    campus_id:       int,
    building:        Optional[str]   = None,
    floor:           Optional[str]   = None,
    poll_interval_s: Optional[float] = None,
    testing_mode:    Optional[bool]  = None,
    methods:         Optional[str]   = None,
    db: Session = Depends(get_db),
):
    """
    Generate config, inject overrides, start the engine.
    Supports ENGINE_MODE=docker (production) or local (desktop/dev).
    """
    try:
        cfg = generate_config(db, campus_id, building, floor)
    except ValueError as e:
        raise HTTPException(404, str(e))

    if poll_interval_s is not None:
        cfg.setdefault("telemetry_config", {})["poll_interval_s"] = poll_interval_s
    if testing_mode is not None:
        cfg.setdefault("system", {})["testing_mode"] = testing_mode
    if methods is not None:
        cfg.setdefault("system", {})["methods"] = [m.strip() for m in methods.split(",") if m.strip()]

    result = start_engine(cfg) if ENGINE_MODE == "docker" else _start_engine_local(cfg)

    if result.get("ok"):
        _log_engine_event(db, "info",
            f"Engine started ({ENGINE_MODE}) — {result.get('message', '')}",
            {"campus_id": campus_id, "mode": ENGINE_MODE, **result})
    else:
        _log_engine_event(db, "security",
            f"Engine failed to start: {result.get('error', 'unknown')}",
            {"campus_id": campus_id, "mode": ENGINE_MODE, **result})
    return result


@router.post("/engine/stop")
def stop(db: Session = Depends(get_db)):
    """Stop the engine (Docker container or local poll loop)."""
    result = stop_engine() if ENGINE_MODE == "docker" else _stop_engine_local()
    level = "info" if result.get("ok") else "warn"
    _log_engine_event(db, level, f"Engine stop ({ENGINE_MODE}): {result}", result)
    return result


@router.get("/engine/status")
def status():
    """Check engine status."""
    if ENGINE_MODE == "docker":
        return engine_status()
    try:
        with httpx.Client(timeout=2.0) as client:
            resp = client.get(f"{ENGINE_API_URL}/health")
            if resp.status_code == 200:
                data = resp.json()
                return {"running": True, "poll_running": data.get("poll_running", False),
                        "mode": "local", "engine_url": ENGINE_API_URL}
    except Exception:
        pass
    return {"running": False, "mode": "local", "engine_url": ENGINE_API_URL}


# ── Survey proxy (platform → engine) ─────────────────────────────────────────
#
# The frontend talks to platform (:8080) only.  These routes forward survey
# requests to the Hybrid engine (:8000) so the frontend never needs to know
# about the engine port.

def _proxy_engine(method: str, path: str, json_body: dict = None) -> dict:
    """Forward a request to the engine and return the JSON response."""
    try:
        with httpx.Client(timeout=10.0) as client:
            resp = getattr(client, method)(f"{ENGINE_API_URL}{path}", json=json_body)
            if resp.status_code == 200:
                return resp.json()
            detail = resp.json() if "application/json" in resp.headers.get("content-type", "") else resp.text
            raise HTTPException(resp.status_code, detail)
    except httpx.ConnectError:
        raise HTTPException(503, f"Engine not reachable at {ENGINE_API_URL}")
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(500, str(exc))


@router.post("/survey/{room_label}/capture")
def survey_capture(room_label: str):
    """Capture live RSSI as a fingerprint for the named room."""
    return _proxy_engine("post", f"/survey/{room_label}/capture")


@router.post("/survey/{room_label}")
def survey_manual(room_label: str, payload: Dict[str, Any]):
    """Submit a manual RSSI vector as a fingerprint."""
    return _proxy_engine("post", f"/survey/{room_label}", payload)


@router.get("/survey/status")
def survey_status():
    """Radiomap overview — rooms, sample counts, coverage."""
    return _proxy_engine("get", "/survey/status")


@router.get("/survey/radiomap")
def survey_radiomap():
    """Full radiomap JSON for the active floor."""
    return _proxy_engine("get", "/survey/radiomap")


@router.delete("/survey/{room_label}")
def survey_delete(room_label: str):
    """Delete all fingerprints for a room."""
    return _proxy_engine("delete", f"/survey/{room_label}")
